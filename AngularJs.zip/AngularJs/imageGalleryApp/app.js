angular.module('imageGalleryApp', [])
  .controller('galleryCtrl', function($scope) {
    $scope.images = [
      { url: 'https://picsum.photos/id/237/200/300', title: 'Forest', category: 'nature' },
      { url: 'https://picsum.photos/id/1074/200/300', title: 'Mountain Lake', category: 'nature' },
      { url: 'https://picsum.photos/id/1036/200/300', title: 'Cityscape', category: 'travel' },
      { url: 'https://picsum.photos/id/1083/200/300', title: 'Beach Sunset', category: 'travel' }
    ];
    $scope.filterByCategory = ''; // Current filter
    $scope.isLightboxOpen = false;
    $scope.lightboxImage = {}; // Currently displayed image in lightbox

    $scope.filterImages = function(category) {
      $scope.filterByCategory = category;
    };

    $scope.openLightbox = function(index) {
      $scope.isLightboxOpen = true;
      $scope.lightboxImage = $scope.images[index];
    };

    $scope.prevImage = function() {
      const currentIndex = $scope.images.indexOf($scope.lightboxImage);
      const prevIndex = (currentIndex - 1 + $scope.images.length) % $scope.images.length;
      $scope.lightboxImage = $scope.images[prevIndex];
    };

    $scope.nextImage = function() {
      const currentIndex = $scope.images.indexOf($scope.lightboxImage);
      const nextIndex = (currentIndex + 1) % $scope.images.length;
      $scope.lightboxImage = $scope.images[nextIndex];
    };

    $scope.closeLightbox = function() {
      $scope.isLightboxOpen = false;
    };
  });
