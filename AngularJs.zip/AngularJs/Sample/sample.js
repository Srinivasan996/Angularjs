var sample = angular.module('sample', []);

sample.controller('employee', ["$scope", function (c) {

    c.name = "srinivasan",
        c.age = 29;

}]);
