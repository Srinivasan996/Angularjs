angular.module('myToDoApp', [])
  .controller('toDoCtrl', function($scope) {
    $scope.toDoList = []; // Empty array to store to-do items

    // Function to add a new item to the list
    $scope.addItem = function() {
      if ($scope.newItem) {
        $scope.toDoList.push({ text: $scope.newItem, completed: false });
        $scope.newItem = ''; // Clear the input field
      }
    };

    // Function to delete an item from the list
    $scope.deleteItem = function(index) {
      $scope.toDoList.splice(index, 1);
    };

    // Function to toggle the completed state of an item
    $scope.toggleCompleted = function(index) {
      $scope.toDoList[index].completed = !$scope.toDoList[index].completed;
    };

    // Function to calculate the number of completed items
    $scope.getCompletedCount = function() {
      return $scope.toDoList.filter(item => item.completed).length;
    };
  });
